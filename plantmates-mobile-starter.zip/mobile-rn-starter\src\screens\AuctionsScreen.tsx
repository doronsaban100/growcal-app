import React, { useEffect, useMemo, useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { EmptyState } from "../components/EmptyState";
import { Header } from "../components/Header";
import { PlantCard } from "../components/PlantCard";
import { Plant } from "../types";
import { colors, spacing } from "../theme";

type Props = {
  plants: Plant[];
  onBid: (id: string) => void;
};

function formatTimeLeft(endTime?: number) {
  if (!endTime) return "24:00:00";
  const diff = endTime - Date.now();
  if (diff <= 0) return "הסתיים";
  const hours = Math.floor(diff / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);
  return `${hours}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

export function AuctionsScreen({ plants, onBid }: Props) {
  const [tick, setTick] = useState(0);
  const auctions = useMemo(() => plants.filter((plant) => plant.status === "auction"), [plants]);

  useEffect(() => {
    const interval = setInterval(() => setTick((value) => value + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <View style={styles.screen}>
      <Header title="מכירות PlantMates" subtitle="הצעות פומביות עם טיפול, מחיר וזמן אמת" />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.helper}>מכרזי הדמו מתעדכנים מקומית. בהמשך נחבר אותם ל-Convex Offers.</Text>
        {auctions.length === 0 ? (
          <EmptyState icon="🔨" title="אין מכרזים פעילים" description="ברגע שצמח יעבור לסטטוס מכרז הוא יופיע כאן." />
        ) : (
          auctions.map((plant) => (
            <PlantCard
              key={`${plant.id}-${tick}`}
              plant={plant}
              auction
              timeLeft={formatTimeLeft(plant.auctionEndTime)}
              onBid={onBid}
            />
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    backgroundColor: colors.background,
    flex: 1,
  },
  content: {
    padding: spacing.screen,
    paddingBottom: 120,
  },
  helper: {
    color: colors.stone500,
    fontSize: 12,
    lineHeight: 18,
    marginBottom: 14,
    textAlign: "right",
    writingDirection: "rtl",
  },
});
