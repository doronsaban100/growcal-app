import React from "react";
import { ScrollView, StyleSheet, View } from "react-native";
import { EmptyState } from "../components/EmptyState";
import { Header } from "../components/Header";
import { PlantCard } from "../components/PlantCard";
import { Plant, PlantStatus } from "../types";
import { colors, spacing } from "../theme";

type Props = {
  title: string;
  subtitle: string;
  emptyIcon: string;
  emptyTitle: string;
  emptyDescription: string;
  plants: Plant[];
  editable?: boolean;
  onWater?: (id: string) => void;
  onStatusChange?: (id: string, status: PlantStatus) => void;
  onPriceChange?: (id: string, price: number) => void;
};

export function InventoryScreen({
  title,
  subtitle,
  emptyIcon,
  emptyTitle,
  emptyDescription,
  plants,
  editable,
  onWater,
  onStatusChange,
  onPriceChange,
}: Props) {
  return (
    <View style={styles.screen}>
      <Header title={title} subtitle={subtitle} />
      <ScrollView contentContainerStyle={styles.content}>
        {plants.length === 0 ? (
          <EmptyState icon={emptyIcon} title={emptyTitle} description={emptyDescription} />
        ) : (
          plants.map((plant) => (
            <PlantCard
              key={plant.id}
              plant={plant}
              editable={editable}
              onWater={onWater}
              onStatusChange={onStatusChange}
              onPriceChange={onPriceChange}
            />
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    backgroundColor: colors.background,
    flex: 1,
  },
  content: {
    padding: spacing.screen,
    paddingBottom: 120,
  },
});
