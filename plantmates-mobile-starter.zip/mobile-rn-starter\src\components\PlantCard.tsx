import React from "react";
import { Image, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Plant, PlantStatus } from "../types";
import { colors } from "../theme";
import { daysSince, formatCurrency, lightIcon, statusLabel, wateringTone } from "../utils/plants";

type Props = {
  plant: Plant;
  editable?: boolean;
  auction?: boolean;
  timeLeft?: string;
  onWater?: (id: string) => void;
  onStatusChange?: (id: string, status: PlantStatus) => void;
  onPriceChange?: (id: string, price: number) => void;
  onBid?: (id: string) => void;
};

export function PlantCard({
  plant,
  editable,
  auction,
  timeLeft,
  onWater,
  onStatusChange,
  onPriceChange,
  onBid,
}: Props) {
  const tone = wateringTone(plant.care.wateringFrequency);
  const wateredDaysAgo = daysSince(plant.wateringDate);

  return (
    <View style={[styles.card, auction && styles.auctionCard]}>
      <View style={styles.topRow}>
        <Image source={{ uri: plant.imageUrl }} style={styles.image} />
        <View style={styles.info}>
          <View style={styles.nameRow}>
            {auction ? <Text style={styles.liveBadge}>Live</Text> : null}
            <Text style={styles.title}>{plant.type}</Text>
          </View>
          <Text style={styles.subTitle}>{plant.subType}</Text>
          <View style={styles.metaRow}>
            <Text style={styles.status}>{statusLabel(plant.status)}</Text>
            <Text style={styles.location}>{plant.location}</Text>
          </View>
          <View style={[styles.carePill, { backgroundColor: tone.backgroundColor, borderColor: tone.borderColor }]}>
            <Text style={[styles.careText, { color: tone.color }]}>
              {lightIcon(plant.care.lightNeeds)}  מים כל {plant.care.wateringFrequency} ימים
              {wateredDaysAgo === 0 ? " · הושקה היום" : ` · לפני ${wateredDaysAgo} ימים`}
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.footer}>
        <View>
          <Text style={styles.priceLabel}>{auction ? "הצעה נוכחית" : "מחיר"}</Text>
          {editable ? (
            <TextInput
              defaultValue={String(plant.currentPrice)}
              keyboardType="numeric"
              onEndEditing={(event) => onPriceChange?.(plant.id, Number(event.nativeEvent.text) || plant.currentPrice)}
              style={styles.priceInput}
            />
          ) : (
            <Text style={styles.price}>{formatCurrency(plant.currentPrice)}</Text>
          )}
        </View>

        {auction ? (
          <Pressable style={styles.bidButton} onPress={() => onBid?.(plant.id)}>
            <Text style={styles.bidText}>הצע {formatCurrency(plant.currentPrice + 10)}</Text>
            {timeLeft ? <Text style={styles.timer}>{timeLeft}</Text> : null}
          </Pressable>
        ) : editable ? (
          <View style={styles.actions}>
            <Pressable style={styles.waterButton} onPress={() => onWater?.(plant.id)}>
              <Ionicons name="water-outline" size={16} color="#fff" />
              <Text style={styles.waterText}>השקיתי</Text>
            </Pressable>
            <View style={styles.statusButtons}>
              {(["personal", "for-sale", "auction"] as PlantStatus[]).map((status) => (
                <Pressable
                  key={status}
                  onPress={() => onStatusChange?.(plant.id, status)}
                  style={[styles.statusButton, plant.status === status && styles.statusButtonActive]}
                >
                  <Text style={[styles.statusButtonText, plant.status === status && styles.statusButtonTextActive]}>
                    {statusLabel(status)}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        ) : (
          <Ionicons name="chevron-back" size={20} color={colors.stone400} />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.stone50,
    borderColor: colors.stone200,
    borderRadius: 18,
    borderWidth: 1,
    marginBottom: 14,
    padding: 14,
  },
  auctionCard: {
    backgroundColor: colors.amber50,
    borderColor: colors.amber200,
  },
  topRow: {
    flexDirection: "row-reverse",
    gap: 14,
  },
  image: {
    backgroundColor: colors.stone100,
    borderRadius: 14,
    height: 82,
    width: 82,
  },
  info: {
    flex: 1,
    minWidth: 0,
  },
  nameRow: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
  },
  title: {
    color: colors.stone800,
    flex: 1,
    fontSize: 17,
    fontWeight: "800",
    textAlign: "right",
    writingDirection: "rtl",
  },
  subTitle: {
    color: colors.stone500,
    fontSize: 14,
    marginTop: 2,
    textAlign: "right",
    writingDirection: "rtl",
  },
  liveBadge: {
    backgroundColor: colors.amber200,
    borderRadius: 999,
    color: colors.amber700,
    fontSize: 10,
    fontWeight: "900",
    overflow: "hidden",
    paddingHorizontal: 8,
    paddingVertical: 4,
    textTransform: "uppercase",
  },
  metaRow: {
    flexDirection: "row-reverse",
    gap: 8,
    marginTop: 8,
  },
  status: {
    backgroundColor: colors.emerald100,
    borderRadius: 999,
    color: colors.emerald800,
    fontSize: 11,
    fontWeight: "800",
    overflow: "hidden",
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  location: {
    color: colors.stone500,
    fontSize: 12,
    paddingVertical: 3,
    writingDirection: "rtl",
  },
  carePill: {
    alignSelf: "flex-end",
    borderRadius: 10,
    borderWidth: 1,
    marginTop: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  careText: {
    fontSize: 11,
    fontWeight: "700",
    writingDirection: "rtl",
  },
  footer: {
    alignItems: "center",
    borderTopColor: colors.stone200,
    borderTopWidth: 1,
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    marginTop: 14,
    paddingTop: 12,
  },
  priceLabel: {
    color: colors.stone500,
    fontSize: 11,
    textAlign: "right",
    writingDirection: "rtl",
  },
  price: {
    color: colors.emerald800,
    fontSize: 20,
    fontWeight: "900",
    textAlign: "right",
  },
  priceInput: {
    backgroundColor: colors.surface,
    borderColor: colors.emerald100,
    borderRadius: 10,
    borderWidth: 1,
    color: colors.emerald800,
    fontSize: 16,
    fontWeight: "900",
    minWidth: 82,
    paddingHorizontal: 10,
    paddingVertical: 4,
    textAlign: "right",
  },
  actions: {
    alignItems: "flex-end",
    gap: 8,
  },
  waterButton: {
    alignItems: "center",
    backgroundColor: colors.emerald600,
    borderRadius: 12,
    flexDirection: "row-reverse",
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  waterText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "800",
  },
  statusButtons: {
    flexDirection: "row-reverse",
    gap: 5,
  },
  statusButton: {
    backgroundColor: colors.surface,
    borderColor: colors.stone200,
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 7,
    paddingVertical: 4,
  },
  statusButtonActive: {
    backgroundColor: colors.emerald700,
    borderColor: colors.emerald700,
  },
  statusButtonText: {
    color: colors.stone600,
    fontSize: 10,
    fontWeight: "800",
  },
  statusButtonTextActive: {
    color: "#fff",
  },
  bidButton: {
    alignItems: "center",
    backgroundColor: colors.amber600,
    borderRadius: 14,
    minWidth: 116,
    paddingHorizontal: 14,
    paddingVertical: 9,
  },
  bidText: {
    color: "#fff",
    fontSize: 13,
    fontWeight: "900",
    writingDirection: "rtl",
  },
  timer: {
    color: colors.amber100,
    fontSize: 11,
    fontVariant: ["tabular-nums"],
    fontWeight: "800",
    marginTop: 2,
  },
});
