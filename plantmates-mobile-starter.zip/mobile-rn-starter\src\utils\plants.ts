import { Plant, PlantStatus } from "../types";

export function formatCurrency(value?: number) {
  return `₪${value ?? 0}`;
}

export function daysSince(timestamp: number) {
  return Math.max(0, Math.floor((Date.now() - timestamp) / 86400000));
}

export function wateringTone(frequency?: number) {
  if (!frequency || frequency > 7) {
    return { backgroundColor: "#ecfdf5", borderColor: "#d1fae5", color: "#047857" };
  }
  if (frequency <= 3) {
    return { backgroundColor: "#fef2f2", borderColor: "#fee2e2", color: "#b91c1c" };
  }
  return { backgroundColor: "#fffbeb", borderColor: "#fef3c7", color: "#b45309" };
}

export function lightIcon(needs?: string) {
  if (!needs) return "◐";
  if (needs.includes("מלא")) return "☀";
  if (needs.includes("חצי") || needs.includes("חלקי") || needs.includes("לא ישיר")) return "◒";
  return "◐";
}

export function statusLabel(status: PlantStatus) {
  if (status === "personal" || status === "collection") return "באוסף";
  if (status === "auction") return "במכרז";
  return "למכירה";
}

export function marketPlants(plants: Plant[]) {
  return plants.filter((plant) => ["for-sale", "selling", "auction"].includes(plant.status));
}
